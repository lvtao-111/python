
import random
import time

import pygame
from pygame.locals import *

WINDOWSIZE = (300,600)      # 屏幕尺寸
# screen = pygame.display.set_mode((300,600))
background_image = pygame.image.load('background.png')
game_over = pygame.image.load('game_over.jpg')
# res = screen.blit(background_image,(0,0))
# pygame.display.flip()
# print(res)
# screen = None
enemy_info = []     #敌人
plane = None   # 我方




class Plane:
    def __init__(self,image_name,screen,xy):
        self.image = pygame.image.load(image_name)
        self.screen = screen
        self.x = xy[0]
        self.y = xy[1]
        self.bullets = []
        self.rec = self.image.get_rect()
        self.position = Rect(self.x, self.y, self.rec.width, self.rec.height)

    def show(self):
        # 显示飞机
        self.screen.blit(self.image,(self.x,self.y))

        # 判断是否移出边界，如果移出边界则删除
        for i in range(len(self.bullets)-1,-1,-1):
            if self.bullets[i].is_out():
                self.bullets.pop(i)

        # 显示子弹
        for bullet in self.bullets:
            bullet.move()
            bullet.show()

    def show_bullet(self):
        for bullet in self.bullets:
            print(bullet,end=' ')
        print()

    def move_left(self):
        self.x -= 5
        if self.x < 0:
            self.x = WINDOWSIZE[0] - self.rec.width

    def move_right(self):
        self.x += 5
        if self.x + self.rec.width > WINDOWSIZE[0]:
            self.x = 0

    def forward(self):
        self.y -= 10

    def fire(self):
        bullet = MyBullet('bullet.png',(self.x + 10,self.y-10),self.screen)
        self.bullets.append(bullet)

class Enemy:
    def __init__(self,image_name,xy,screen):
        self.image = pygame.image.load(image_name)
        self.x = xy[0]
        self.y = xy[1]
        rec = self.image.get_rect()
        self.position = Rect(self.x,self.y,rec.width,rec.height)
        self.screen = screen
        self.e_bullets = []
        self.bullets_x = self.x + 10
        self.bullets_y = self.y

    def show_bullet(self):
        for bullet in self.e_bullets:
            print(bullet,end=' ')
        print()


    def show(self):
        self.screen.blit(self.image,(self.x,self.y))
        self.forward()

        # 判断是否移出边界，如果移出边界则删除
        for i in range(len(self.e_bullets) - 1, -1, -1):
            if self.e_bullets[i].is_out():
                self.e_bullets.pop(i)

        # 显示子弹
        for bullet in self.e_bullets:
            bullet.move()
            bullet.show()

    def move_left(self):
        self.x += 5
        self.position.x = self.x

    def forward(self):
        self.y += 5
        self.position.y = self.y

    def fire(self):
        # self.bullets_x += 10
        self.bullets_y =self.position.y
        bullet = EnemyBullet('bullet.png',(self.bullets_x ,self.bullets_y),self.screen)
        self.e_bullets.append(bullet)


    def plane_bump_enemybullet(self):
        for b in self.e_bullets:
            if pygame.Rect.colliderect(b.position, plane.position):
                exit()
                return False



class Bullet:
    def __init__(self,image_name,xy,screen):
        self.x = xy[0]
        self.y = xy[1]
        self.screen = screen
        self.image = pygame.image.load(image_name)
        rec = self.image.get_rect()
        self.position = Rect(self.x,self.y,rec.width,rec.height)

    def __str__(self):
        return f'({self.x},{self.y},{self.position.width},{self.position.height})'

    def is_out(self):
        if (self.x < WINDOWSIZE[0]) or (self.y > WINDOWSIZE[1]-50):
            return True

    def move(self):
        pass

    def show(self):
        self.position = self.screen.blit(self.image,(self.x,self.y))

class MyBullet(Bullet):
    def move(self):
        self.y -= 5

    def is_out(self):
        return self.y <= 0

class EnemyBullet(Bullet):
    def move(self):
        self.y += 10

    def is_out(self):
        if self.y > (WINDOWSIZE[1]+10):
            return True






def game_init():
    pygame.init()
    global screen
    screen = pygame.display.set_mode(WINDOWSIZE)
    pygame.display.set_caption('打飞机')
    screen.blit(background_image, (0, 0))

def times(t1,n):
    t2 =time.time()
    if t2 - t1 >= n:
        return True


def generate_enemy():
    enemy = Enemy('enemy1.png',(random.randint(50,WINDOWSIZE[0]-50),0),screen)
    enemy_bullet_time = time.time()
    enemys = [enemy,enemy_bullet_time]
    enemy_info.append(enemys)
    enemys[0].fire()



def enemy_bump_mybullet():
    for i in range(len(enemy_info)-1,-1,-1):
        index = -1
        for j in range(len(plane.bullets)-1,-1,-1):
            if pygame.Rect.colliderect(enemy_info[i][0].position,plane.bullets[j].position):
                enemy_info.pop(i)
                plane.bullets.pop(j)
                return

# def plane_bump_enemybullet():
#     for i in range(len(enemy_info)):
#         for b in range(len(enemy_info[i][0].e_bullets)):
#             if pygame.Rect.colliderect(enemy_info[i][0].e_bullets[b].position,plane.position):
#                 exit()
#                 return False
def main():

    global plane
    ALERT = USEREVENT +1
    pygame.time.set_timer(ALERT,5000)
    game_init()
    plane = Plane('plane.png',screen,(150,550))
    # res = plane.image.get_rect()



    running = True
    enemy_time = time.time()
    z = 0
    while running:
        screen.fill((255, 255, 255))
        screen.blit(background_image,(0,0))
        plane.show()

        for enemy in enemy_info:
            enemy[0].show()
            if times(enemy[1],1):
                enemy[0].fire()
                enemy[1] = time.time()


        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            elif event.type == KEYDOWN:
                if event.key == K_SPACE:
                    plane.fire()




        key_list = pygame.key.get_pressed()
        if key_list[pygame.K_UP]:
            pass
        elif key_list[pygame.K_LEFT]:
            plane.move_left()
        elif key_list[pygame.K_RIGHT]:
            plane.move_right()
        pygame.time.Clock().tick(30)
        enemy_bump_mybullet()
        pygame.display.flip()
        plane_bump_enemybullet()

        # if times(enemy_time,random.randint(1,20)):

        if times(enemy_time,z):
            generate_enemy()
            enemy_time = time.time()
            z = random.randint(1,2)


if __name__ == '__main__':
    main()
















































































